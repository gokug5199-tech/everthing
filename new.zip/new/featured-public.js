(function(){'use strict';
const base='https://tnavsfbolastevebukxl.supabase.co/rest/v1/',key='sb_publishable_3FX_mPM-A6dIY-nQTtFZQg_5HPoWO9B';
async function get(table,query){const r=await fetch(base+table+'?'+query,{headers:{apikey:key},signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error('Could not load latest content');return r.json();}
const cover=url=>{try{const u=new URL(url,location.href);return ['http:','https:'].includes(u.protocol)?u.href:'';}catch{return ''}};
function heading(title,more){const head=document.createElement('div');head.className='te-latest-heading';const h=document.createElement('h2');h.textContent=title;head.append(h);if(more){const a=document.createElement('a');a.href='anime.html';a.textContent='Browse all anime →';head.append(a);}return head;}
function card(a,ep){const link=document.createElement('a');link.className='te-latest-card';link.href=ep?`watch.html?anime=${encodeURIComponent(a.id)}&season=${ep.season_number}&episode=${ep.episode_number}`:`anime-details.html?id=${encodeURIComponent(a.id)}`;const img=document.createElement('img');img.src=cover(a.image)||'image/anime/attack-on-titan.jpg';img.alt=a.title||'';img.loading='lazy';const content=document.createElement('div');const title=document.createElement('strong');title.textContent=a.title;const sub=document.createElement('small');sub.textContent=ep?`Season ${ep.season_number} · Episode ${ep.episode_number}${ep.title?' · '+ep.title:''}`:(Array.isArray(a.genres)&&a.genres.length?a.genres.slice(0,2).join(' · '):'Anime');content.append(title,sub);link.append(img,content);return link;}
function insertLatestBlock(outer,page){
  if(page==='anime.html'){
    const section=document.querySelector('.anime-section');
    if(section){
      outer.classList.add('te-latest-before-list');
      section.insertBefore(outer, section.firstChild);
      return true;
    }
  }
  if(page==='index.html' || page===''){
    const cards=document.querySelector('.cards-section');
    if(cards && cards.parentNode){
      outer.classList.add('te-latest-before-cards');
      cards.parentNode.insertBefore(outer,cards);
      return true;
    }
  }
  const main=document.querySelector('main')||document.body;
  main.append(outer);
  return true;
}
async function init(){
  const page=location.pathname.split('/').pop().toLowerCase();
  if(!['index.html','anime.html',''].includes(page))return;
  let featured;
  try{featured=await get('site_featured','select=kind,anime_id,season_number,episode_number,position&order=kind.asc,position.asc,created_at.asc&limit=100');}
  catch(e){console.warn('Latest sections unavailable:',e);return;}
  if(!featured.length)return;
  const ids=[...new Set(featured.map(x=>x.anime_id).filter(Boolean))];
  if(!ids.length)return;
  let anime;
  try{anime=await get('site_anime','select=id,title,image,genres&id=in.('+ids.map(x=>'"'+String(x).replaceAll('"','')+'"').join(',')+')');}
  catch(e){console.warn(e);return;}
  const byId=new Map(anime.map(a=>[a.id,a]));
  const epEntries=featured.filter(x=>x.kind==='episode');
  let eps=[];
  if(epEntries.length){
    try{eps=await get('site_episodes','select=anime_id,season_number,episode_number,title&limit=5000');}
    catch(e){console.warn(e);}
  }
  const epMap=new Map(eps.map(e=>[`${e.anime_id}/${e.season_number}/${e.episode_number}`,e]));
  const outer=document.createElement('section');
  outer.className='te-latest-wrap';
  for(const kind of ['anime','episode']){
    const group=featured.filter(x=>x.kind===kind);
    if(!group.length) continue;
    const section=document.createElement('section');
    section.className='te-latest-section';
    section.append(heading(kind==='anime'?'Latest Anime':'Latest Episodes',kind==='anime'));
    const grid=document.createElement('div');
    grid.className='te-latest-grid';
    group.forEach(item=>{
      const a=byId.get(item.anime_id);
      if(!a) return;
      const e=kind==='episode'?epMap.get(`${item.anime_id}/${item.season_number}/${item.episode_number}`):null;
      if(kind==='episode'&&!e) return;
      grid.append(card(a,e));
    });
    if(!grid.children.length) continue;
    section.append(grid);
    outer.append(section);
  }
  if(!outer.children.length)return;
  insertLatestBlock(outer,page);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
